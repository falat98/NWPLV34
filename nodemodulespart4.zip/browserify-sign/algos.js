module.exports = require('./browser/algorithms.json')
