// Re-export lib/utils, so that consumers can import
// babel-plugin-dynamic-import-node/utils instead of
// babel-plugin-dynamic-import-node/lib/utils

// eslint-disable-next-line import/no-unresolved
module.exports = require('./lib/utils');
