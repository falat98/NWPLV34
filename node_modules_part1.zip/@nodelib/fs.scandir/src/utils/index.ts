import * as fs from './fs';

export {
	fs
};
