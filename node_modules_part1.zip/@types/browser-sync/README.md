# Installation
> `npm install --save @types/browser-sync`

# Summary
This package contains type definitions for browser-sync (http://www.browsersync.io/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/browser-sync

Additional Details
 * Last updated: Mon, 19 Aug 2019 00:51:08 GMT
 * Dependencies: @types/micromatch, @types/chokidar, @types/serve-static, @types/node
 * Global values: none

# Credits
These definitions were written by Asana <https://asana.com>, Joe Skeen <https://github.com/joeskeen>, Thomas "Thasmo" Deinhamer <https://thasmo.com/>, Kiyotoshi Ichikawa <https://github.com/aznnomness>, and Yuma Hashimoto <https://github.com/yuma84>.
