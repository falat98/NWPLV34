# @babel/plugin-transform-modules-amd

> This plugin transforms ES2015 modules to AMD

See our website [@babel/plugin-transform-modules-amd](https://babeljs.io/docs/en/babel-plugin-transform-modules-amd) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-modules-amd
```

or using yarn:

```sh
yarn add @babel/plugin-transform-modules-amd --dev
```
