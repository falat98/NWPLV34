<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Choose a user</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <style>
            .container {
                width: 100vw;
                height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .justify-content-center {
                width: 800px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <?php if(count($users) > 0): ?>
            <table class="table table-striped table-hover">
                <thead class="thead-dark">
                    <th>ID</th>
                    <th>Name</th>
                    <th>E-mail</th>
                    <th></th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($user->id != Auth::user()->getId()): ?>
                        <td><div><?php echo e($user->id); ?></div></td>
                        <td><div><?php echo e($user->name); ?></div></td>
                        <td><div><?php echo e($user->email); ?></div></td>
                        <td>
                            <form id="form" action="<?php echo e(route('adduser')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type=number value="<?php echo e($project_id); ?>" name="project_id" id="project_id" style=" display:none">
                                <input type=number value="<?php echo e($user->id); ?>" name="user_id" id="user_id" style=" display:none">
                                <button class="btn btn-primary" type="submit">Choose</button>
                            </form>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </body>
</html>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekti\resources\views/users.blade.php ENDPATH**/ ?>