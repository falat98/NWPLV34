<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Edit project</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <style>
            .container {
                width: 100vw;
                height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                flex-direction: column;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="justify-content-center">
                <div class="card">
                    <div class="card-header">Edit project <?php echo e($project->name); ?></div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('saveproject', $project->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="PUT">
                        <?php if($project->leader == Auth::user()->getId()): ?>
                            <div class="form-group row">
                                <label for="name">Name: </label>
                                <input class="form-control" type="text" name="name" id="name" value="<?php echo e($project->name); ?>" required>
                            </div>
                            <div class="form-group row">
                                <label for="description">Description: </label>
                                <textarea  class="form-control" rows=5 name="description" id="description" required><?php echo e($project->description); ?></textarea>
                            </div>
                            <div class="form-group row">
                                <label for="price">Price: </label>
                                <input  class="form-control" type="number" name="price" id="price" value="<?php echo e($project->price); ?>"  required>
                            </div>
                            <div class="form-group row">
                        <?php endif; ?>
                                <label for="worksdone">Works done: </label>
                                <textarea  class="form-control" rows=5 name="worksdone" id="worksdone" required> <?php echo e($project->works_done); ?></textarea>
                            </div>
                        <?php if($project->leader == Auth::user()->getId()): ?>
                            <div class="form-group row">
                                <label for="startdate">Start date: </label>
                                <input  class="form-control" type="datetime-local" name="startdate" id="startdate" value="<?php echo e($project->start_date); ?>"  required>
                            </div>
                            <div class="form-group row">
                                <label for="enddate">End date: </label>
                                <input  class="form-control" type="datetime-local" name="enddate" id="enddate" value="<?php echo e($project->end_date); ?>"  required>
                            </div>
                        <?php endif; ?>
                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekti\resources\views/editproject.blade.php ENDPATH**/ ?>