<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>All projects</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <style>
            .container {
                width: 100vw;
                height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .justify-content-center {
                width: 800px;
            }
            .link {
                color: black !important;
                text-decoration: underline;
            }
            .link:hover {
                color: #007bff !important;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <?php if(count($projects) > 0): ?>
                <table class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <th>#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Works done</th>
                        <th>Start date</th>
                        <th>End date</th>
                        <th></th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><div><?php echo e($project->id); ?></div></td>
                            <td><div><?php echo e($project->name); ?></div></td>
                            <td><div><?php echo e($project->description); ?></div></td>
                            <td><div><?php echo e($project->price); ?></div></td>
                            <td><div><?php echo e($project->jobs_done); ?></div></td>
                            <td><div><?php echo e($project->start_date); ?></div></td>
                            <td><div><?php echo e($project->end_date); ?></div></td>
                            <td><a class="link" href="<?php echo e(route('editproject', $project->id)); ?>">Edit</a></td>
                            <?php if($project->leader == Auth::user()->getId()): ?>
                            <td><a class="link" href="<?php echo e(route('users', $project->id)); ?>">Add user</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                No projects.
            <?php endif; ?>
        </div>
    </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekti\resources\views/projects.blade.php ENDPATH**/ ?>